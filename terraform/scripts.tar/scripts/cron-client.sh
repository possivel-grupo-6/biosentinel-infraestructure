#!/bin/bash
/usr/local/bin/jupyter nbconvert --to notebook --execute /opt/jupyter/notebook/move_client_db.ipynb --output /opt/jupyter/notebook/auto-run/saida-client.ipynb