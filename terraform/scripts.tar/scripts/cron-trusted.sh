#!/bin/bash
/usr/local/bin/jupyter nbconvert --to notebook --execute /opt/jupyter/notebook/move_trusted_client.ipynb --output /opt/jupyter/notebook/auto-run/saida-trusted.ipynb