#!/bin/bash
/usr/local/bin/jupyter nbconvert --to notebook --execute /opt/jupyter/notebook/move_raw_trusted.ipynb --output /opt/jupyter/notebook/auto-run/saida-raw.ipynb